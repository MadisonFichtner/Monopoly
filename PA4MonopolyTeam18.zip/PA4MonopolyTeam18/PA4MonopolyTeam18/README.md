1) The only dependency of our monopoly program is JavaFX, which was used to create our GUI

2) To run monopoly from the command line:
	1. Unzip the folder "PA4MonopolyTeam18"
	2. Open command line
	3. Navigate to where PA4MonopolyTeam18 was unzipped and saved to
	4. Open the folder named "ESOF322_monopoly"
	5. Type "java -jar monopoly.jar" into the command line
	6. Enter game mode (english or msu) and the users names
	7. Enjoy a game of monopoly
	
3) The only missing component from our program is the timeout. Everything else is fully functional, and looks exceptional.